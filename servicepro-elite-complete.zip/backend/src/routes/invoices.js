const express = require('express');
const router = express.Router();

// Placeholder for invoice routes
router.get('/', (req, res) => {
  res.json({ message: 'Invoices endpoint - implementation pending' });
});

module.exports = router;