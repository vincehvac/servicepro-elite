const express = require('express');
const router = express.Router();

// Placeholder for job routes
router.get('/', (req, res) => {
  res.json({ message: 'Jobs endpoint - implementation pending' });
});

module.exports = router;